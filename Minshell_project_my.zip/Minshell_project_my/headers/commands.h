// #ifndef COMMANDS_H
// # define COMMANDS_H

// # include <unistd.h>
// #include "./minishell.h"

// void	cmd_pwd();
// void	cmd_echo(t_node n);

// #endif